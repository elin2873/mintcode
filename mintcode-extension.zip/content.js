(()=>{var s={START_INTERVIEW:"START_INTERVIEW",CANCEL_INTERVIEW:"CANCEL_INTERVIEW",VOID_INTERVIEW:"VOID_INTERVIEW",FETCH_RANDOM_PROBLEM:"FETCH_RANDOM_PROBLEM",INJECT_OVERLAY:"INJECT_OVERLAY",AI_MESSAGE:"AI_MESSAGE",EVALUATION_RESULT:"EVALUATION_RESULT",INTERVIEW_ENDED:"INTERVIEW_ENDED",PROBLEM_SELECTED:"PROBLEM_SELECTED",PROBLEM_FETCH_FAILED:"PROBLEM_FETCH_FAILED",OVERLAY_READY:"OVERLAY_READY",INTERVIEW_STARTED:"INTERVIEW_STARTED",INTERVIEW_FINISHED:"INTERVIEW_FINISHED",CODE_SNAPSHOT:"CODE_SNAPSHOT",TRANSCRIPT_UPDATE:"TRANSCRIPT_UPDATE",MIC_STATUS:"MIC_STATUS",SUBMISSION_RESULT:"SUBMISSION_RESULT",PROBLEM_LOADED:"PROBLEM_LOADED",ERROR:"ERROR",STATE_UPDATE:"STATE_UPDATE",GET_STATE:"GET_STATE"};var l=null;function P(e,t){l=document.createElement("div"),l.id="ai-interview-countdown",l.innerHTML=`
    <div class="countdown-backdrop">
      <div class="countdown-content">
        <div class="countdown-label">Interview Starting</div>
        <div class="countdown-problem">${e.title}</div>
        <div class="countdown-difficulty ${e.difficulty.toLowerCase()}">${e.difficulty}</div>
        <div class="countdown-number">5</div>
        <div class="countdown-sub">Get ready...</div>
      </div>
    </div>
  `,document.body.appendChild(l);let n=5,r=l.querySelector(".countdown-number"),o=setInterval(()=>{n--,n<=0?(clearInterval(o),ce(()=>{R(),t&&t()})):r.textContent=n},1e3)}function ce(e){l?(l.style.transition="opacity 0.5s ease",l.style.opacity="0",setTimeout(e,500)):e()}function R(){l&&(l.remove(),l=null)}function k(e){return String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}var c=null;function ae(){c=document.createElement("div"),c.id="ai-interview-results",c.style.display="none",c.innerHTML=`
    <div class="results-backdrop">
      <div class="results-card">
        <div class="results-header">Interview Complete</div>
        <div class="results-overall">
          <div class="results-score-ring">
            <svg viewBox="0 0 120 120" class="score-ring-svg">
              <circle cx="60" cy="60" r="50" class="ring-bg" />
              <circle cx="60" cy="60" r="50" class="ring-fill" id="results-ring-fill" />
            </svg>
            <div class="score-number" id="results-score-number">0</div>
          </div>
        </div>
        <div class="results-details" id="results-details"></div>
        <div class="results-summary" id="results-summary">
          <h3>Summary</h3>
          <p id="results-summary-text"></p>
        </div>
        <div class="results-recommendation" id="results-recommendation"></div>
        <button class="ai-btn ai-btn-close" id="results-close-btn">Close</button>
      </div>
    </div>
  `,document.body.appendChild(c),c.querySelector("#results-close-btn").addEventListener("click",()=>{_()})}function $(e){c||ae(),c.style.display="block";let t=e.overallScore||0,n=c.querySelector("#results-score-number"),r=c.querySelector("#results-ring-fill");le(n,r,t);let o=c.querySelector("#results-details"),i=e.scores||{};o.innerHTML=Object.entries(i).map(([ne,q])=>{let re=k(ne.replace(/([A-Z])/g," $1").replace(/^./,se=>se.toUpperCase())),S=q.score||0,oe=k(q.reason||""),ie=S>=7?"#4caf50":S>=4?"#ff9800":"#f44336";return`
      <div class="result-dimension">
        <div class="dimension-header">
          <span>${re}</span>
          <span class="dimension-score">${S}/10</span>
        </div>
        <div class="dimension-bar">
          <div class="dimension-fill" style="width:${S*10}%;background:${ie}"></div>
        </div>
        <div class="dimension-reason">${oe}</div>
      </div>
    `}).join("");let m=c.querySelector("#results-summary-text");m.textContent=e.summary||"";let d=c.querySelector("#results-recommendation"),I=e.recommendation||"";d.textContent=I,d.className="results-recommendation",I.includes("Hire")?d.classList.add("rec-hire"):I.includes("No")?d.classList.add("rec-no"):d.classList.add("rec-maybe")}function le(e,t,n){let o=2*Math.PI*50,i=0;t.style.strokeDasharray=o;let m=setInterval(()=>{i+=.5,i>=n&&(i=n,clearInterval(m)),e.textContent=Math.round(i);let d=o-i/10*o;t.style.strokeDashoffset=d},30)}function _(){c&&(c.remove(),c=null)}var a=null,E=!1,B=null,C=null,g=null;function H(e){if(E)return;B=e.onResult||(()=>{}),C=e.onError||(()=>{});let t=window.SpeechRecognition||window.webkitSpeechRecognition;if(!t){C("Speech recognition not supported");return}a=new t,a.continuous=!0,a.interimResults=!0,a.lang="en-US";let n="";a.onresult=r=>{let o="";for(let i=r.resultIndex;i<r.results.length;i++)r.results[i].isFinal?n+=r.results[i][0].transcript+" ":o+=r.results[i][0].transcript;B(n,o)},a.onerror=r=>{r.error==="no-speech"||r.error==="aborted"||(C(r.error),z())},a.onend=()=>{E&&z()},E=!0,a.start()}function z(){g&&clearTimeout(g),g=setTimeout(()=>{if(E&&a)try{a.start()}catch{}},300)}function A(){if(E=!1,g&&(clearTimeout(g),g=null),a){try{a.stop()}catch{}a=null}}var D=!1;function W(e,t){return new Promise(n=>{if(!window.speechSynthesis){n();return}window.speechSynthesis.cancel();let r=new SpeechSynthesisUtterance(e);r.rate=1,r.pitch=1,r.volume=1,r.lang="en-US";let i=window.speechSynthesis.getVoices().find(m=>m.name.includes("Google US English")||m.name.includes("Microsoft David"));i&&(r.voice=i),D=!0,r.onend=()=>{D=!1,n()},r.onerror=()=>{D=!1,n()},window.speechSynthesis.speak(r)})}var j=`/* ===== COUNTDOWN ===== */\r
#ai-interview-countdown {\r
  position: fixed;\r
  top: 0;\r
  left: 0;\r
  width: 100%;\r
  height: 100%;\r
  z-index: 999999;\r
}\r
\r
.countdown-backdrop {\r
  width: 100%;\r
  height: 100%;\r
  background: rgba(0, 0, 0, 0.85);\r
  backdrop-filter: blur(20px);\r
  -webkit-backdrop-filter: blur(20px);\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
}\r
\r
.countdown-content {\r
  text-align: center;\r
  color: #fff;\r
  animation: fadeIn 0.5s ease;\r
}\r
\r
.countdown-label {\r
  font-size: 24px;\r
  font-weight: 300;\r
  color: #888;\r
  margin-bottom: 8px;\r
  letter-spacing: 2px;\r
  text-transform: uppercase;\r
}\r
\r
.countdown-problem {\r
  font-size: 28px;\r
  font-weight: 600;\r
  margin-bottom: 8px;\r
}\r
\r
.countdown-difficulty {\r
  display: inline-block;\r
  font-size: 12px;\r
  font-weight: 600;\r
  padding: 4px 12px;\r
  border-radius: 12px;\r
  text-transform: uppercase;\r
  letter-spacing: 1px;\r
  margin-bottom: 24px;\r
}\r
\r
.countdown-difficulty.easy { background: #4caf50; color: #fff; }\r
.countdown-difficulty.medium { background: #ff9800; color: #fff; }\r
.countdown-difficulty.hard { background: #f44336; color: #fff; }\r
\r
.countdown-number {\r
  font-size: 120px;\r
  font-weight: 800;\r
  line-height: 1;\r
  margin-bottom: 8px;\r
  background: linear-gradient(135deg, #4fc3f7, #7c4dff);\r
  -webkit-background-clip: text;\r
  -webkit-text-fill-color: transparent;\r
  background-clip: text;\r
  animation: pulse 1s ease-in-out infinite;\r
}\r
\r
.countdown-sub {\r
  font-size: 16px;\r
  color: #666;\r
  letter-spacing: 1px;\r
}\r
\r
@keyframes pulse {\r
  0%, 100% { transform: scale(1); }\r
  50% { transform: scale(1.05); }\r
}\r
\r
@keyframes fadeIn {\r
  from { opacity: 0; transform: translateY(-20px); }\r
  to { opacity: 1; transform: translateY(0); }\r
}\r
\r
/* ===== INTERVIEW UI ===== */\r
#ai-interview-ui {\r
  position: fixed;\r
  top: 0;\r
  left: 0;\r
  width: 100%;\r
  z-index: 999990;\r
  pointer-events: none;\r
}\r
\r
#ai-interview-ui > * {\r
  pointer-events: auto;\r
}\r
\r
.interview-top-bar {\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
  padding: 8px 16px;\r
  background: rgba(26, 26, 46, 0.95);\r
  border-bottom: 1px solid #333;\r
  backdrop-filter: blur(10px);\r
  color: #e0e0e0;\r
}\r
\r
.interview-timer {\r
  font-size: 20px;\r
  font-weight: 700;\r
  font-variant-numeric: tabular-nums;\r
  color: #4fc3f7;\r
  min-width: 80px;\r
}\r
\r
.interview-mic {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  font-size: 14px;\r
}\r
\r
.mic-icon { font-size: 18px; }\r
.mic-status { color: #888; }\r
\r
.interview-controls {\r
  display: flex;\r
  gap: 8px;\r
}\r
\r
.ai-btn {\r
  padding: 6px 14px;\r
  border: none;\r
  border-radius: 6px;\r
  font-size: 12px;\r
  font-weight: 600;\r
  cursor: pointer;\r
  transition: background 0.2s;\r
}\r
\r
.ai-btn-start {\r
  background: #4fc3f7;\r
  color: #1a1a2e;\r
}\r
.ai-btn-start:hover { background: #29b6f6; }\r
\r
.ai-btn-finish {\r
  background: #d32f2f;\r
  color: #fff;\r
}\r
.ai-btn-finish:hover { background: #c62828; }\r
\r
.ai-btn-close {\r
  background: #333;\r
  color: #e0e0e0;\r
  margin-top: 16px;\r
}\r
.ai-btn-close:hover { background: #444; }\r
\r
.interview-ai-message {\r
  position: fixed;\r
  bottom: 24px;\r
  right: 24px;\r
  max-width: 400px;\r
  background: rgba(26, 26, 46, 0.97);\r
  border: 1px solid #4fc3f7;\r
  border-radius: 12px;\r
  padding: 16px;\r
  display: none;\r
  animation: slideUp 0.3s ease;\r
}\r
\r
.ai-message-label {\r
  font-size: 11px;\r
  font-weight: 600;\r
  text-transform: uppercase;\r
  letter-spacing: 1px;\r
  color: #4fc3f7;\r
  margin-bottom: 6px;\r
}\r
\r
.ai-message-content {\r
  font-size: 14px;\r
  line-height: 1.5;\r
  color: #e0e0e0;\r
}\r
\r
@keyframes slideUp {\r
  from { opacity: 0; transform: translateY(20px); }\r
  to { opacity: 1; transform: translateY(0); }\r
}\r
\r
/* ===== RESULTS ===== */\r
#ai-interview-results {\r
  position: fixed;\r
  top: 0;\r
  left: 0;\r
  width: 100%;\r
  height: 100%;\r
  z-index: 999999;\r
  pointer-events: none;\r
}\r
\r
#ai-interview-results > * {\r
  pointer-events: auto;\r
}\r
\r
.results-backdrop {\r
  width: 100%;\r
  height: 100%;\r
  background: rgba(0, 0, 0, 0.85);\r
  backdrop-filter: blur(20px);\r
  -webkit-backdrop-filter: blur(20px);\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  overflow-y: auto;\r
}\r
\r
.results-card {\r
  background: #1a1a2e;\r
  border: 1px solid #333;\r
  border-radius: 16px;\r
  padding: 32px;\r
  max-width: 500px;\r
  width: 90%;\r
  max-height: 90vh;\r
  overflow-y: auto;\r
  color: #e0e0e0;\r
}\r
\r
.results-header {\r
  font-size: 24px;\r
  font-weight: 700;\r
  text-align: center;\r
  margin-bottom: 24px;\r
  color: #fff;\r
}\r
\r
.results-overall {\r
  display: flex;\r
  justify-content: center;\r
  margin-bottom: 24px;\r
}\r
\r
.results-score-ring {\r
  position: relative;\r
  width: 120px;\r
  height: 120px;\r
}\r
\r
.score-ring-svg {\r
  width: 120px;\r
  height: 120px;\r
  transform: rotate(-90deg);\r
}\r
\r
.ring-bg {\r
  fill: none;\r
  stroke: #333;\r
  stroke-width: 8;\r
}\r
\r
.ring-fill {\r
  fill: none;\r
  stroke: #4fc3f7;\r
  stroke-width: 8;\r
  stroke-linecap: round;\r
  stroke-dasharray: 314;\r
  stroke-dashoffset: 314;\r
  transition: stroke-dashoffset 0.3s;\r
}\r
\r
.score-number {\r
  position: absolute;\r
  top: 50%;\r
  left: 50%;\r
  transform: translate(-50%, -50%);\r
  font-size: 36px;\r
  font-weight: 800;\r
  color: #fff;\r
}\r
\r
.results-details {\r
  margin-bottom: 24px;\r
}\r
\r
.result-dimension {\r
  margin-bottom: 16px;\r
}\r
\r
.dimension-header {\r
  display: flex;\r
  justify-content: space-between;\r
  font-size: 13px;\r
  margin-bottom: 4px;\r
}\r
\r
.dimension-score {\r
  font-weight: 700;\r
  color: #4fc3f7;\r
}\r
\r
.dimension-bar {\r
  height: 6px;\r
  background: #333;\r
  border-radius: 3px;\r
  overflow: hidden;\r
  margin-bottom: 4px;\r
}\r
\r
.dimension-fill {\r
  height: 100%;\r
  border-radius: 3px;\r
  transition: width 0.5s ease;\r
}\r
\r
.dimension-reason {\r
  font-size: 11px;\r
  color: #888;\r
  line-height: 1.4;\r
}\r
\r
.results-summary {\r
  margin-bottom: 24px;\r
}\r
\r
.results-summary h3 {\r
  font-size: 14px;\r
  font-weight: 600;\r
  margin-bottom: 8px;\r
  color: #fff;\r
}\r
\r
.results-summary p {\r
  font-size: 13px;\r
  line-height: 1.6;\r
  color: #ccc;\r
}\r
\r
.results-recommendation {\r
  text-align: center;\r
  font-size: 18px;\r
  font-weight: 700;\r
  padding: 12px;\r
  border-radius: 8px;\r
  margin-bottom: 16px;\r
}\r
\r
.rec-hire { background: rgba(76, 175, 80, 0.2); color: #4caf50; }\r
.rec-maybe { background: rgba(255, 152, 0, 0.2); color: #ff9800; }\r
.rec-no { background: rgba(244, 67, 54, 0.2); color: #f44336; }\r
\r
/* ===== SCROLLBAR ===== */\r
.results-card::-webkit-scrollbar {\r
  width: 6px;\r
}\r
.results-card::-webkit-scrollbar-track {\r
  background: transparent;\r
}\r
.results-card::-webkit-scrollbar-thumb {\r
  background: #444;\r
  border-radius: 3px;\r
}\r
`;var de=15e3,fe="mintcode:get-code",pe="mintcode:code",me=['[data-e2e-locator="submission-result"]','[data-e2e-locator*="result"]','[data-e2e-locator*="Result"]',".ant-alert",'[class*="submission-result"]','[class*="SubmissionResult"]'],ge=/(Accepted|Wrong Answer|Time Limit Exceeded|Memory Limit Exceeded|Runtime Error|Compile Error|Output Limit Exceeded|Stack Overflow|Segmentation Fault|Presentation Error|Internal Error)/,T=null,M=!1,x="",J="",N="",p=!1,f=null,u=null,y=null,h=null,b=null,U="",v=!1,V=0;chrome.runtime.onMessage.addListener((e,t,n)=>{switch(e.type){case s.INJECT_OVERLAY:ve(e),n({ok:!0});break;case s.AI_MESSAGE:chrome.storage.sync.get({ttsMuted:!1},r=>{r.ttsMuted||W(e.text)});break;case s.EVALUATION_RESULT:$(e.result);break;case s.INTERVIEW_ENDED:Re();break;case"TIME_EXPIRED":setTimeout(()=>G(),2e3);break;case"FINISH_EARLY":G();break;case s.ERROR:break}return!1});document.addEventListener(pe,e=>{typeof e.detail=="string"&&L(e.detail)});function F(){try{document.dispatchEvent(new CustomEvent(fe))}catch{}}function L(e){!e||e===x||!p||(x=e,X(e))}function he(){let e=document.querySelector('[data-track-load="description_content"]')||document.querySelector(".elfjS")||document.querySelector('[class*="question-content"]')||document.querySelector('[class*="Description"]'),t=document.querySelector('[data-cy="question-title"]')||document.querySelector('a[href*="/problems/"][class*="title"]')||document.querySelector('div[class*="text-title"]'),n=document.querySelector("[diff]")||document.querySelector(".text-difficulty-easy, .text-difficulty-medium, .text-difficulty-hard")||document.querySelector('[class*="difficulty"]'),r="";if(n){let o=(n.getAttribute("diff")||n.textContent||"").trim();/easy/i.test(o)?r="Easy":/medium/i.test(o)?r="Medium":/hard/i.test(o)&&(r="Hard")}return{title:t?t.textContent.trim():"",content:e?e.innerHTML:"",difficulty:r}}function be(){let e=['select[class*="language"]','button[class*="language"]','[data-cy*="lang-select"]',"#lang-select"];for(let t of e){let n=document.querySelector(t);if(n){J=n.textContent.trim()||n.value||"";break}}}function O(){let e=document.querySelectorAll(".monaco-editor");if(!e.length)return"";let t="";for(let n of e){let r=n.querySelectorAll(".view-lines .view-line, .view-line"),o=Array.from(r).map(i=>i.textContent||"").join(`
`);o.length>t.length&&(t=o)}return t}function Ee(){F();let e=O();e&&L(e),T=setInterval(()=>{F();let t=O();t&&L(t)},de)}function X(e){chrome.runtime.sendMessage({type:s.CODE_SNAPSHOT,code:e}).catch(()=>{})}function ye(){h||(document.addEventListener("click",Z,!0),h=new MutationObserver(()=>{b||(b=setTimeout(()=>{b=null,xe()},300))}),h.observe(document.body,{childList:!0,subtree:!0,characterData:!0}))}function Z(e){let t=e.target&&e.target.closest?e.target.closest("button"):null;t&&/submit/i.test(t.textContent||"")&&(v=!0,V=Date.now())}function xe(){let e=Se();if(!e)return;let t=e.match(ge);if(!t)return;let n=t[1];if(v){if(Date.now()-V<800)return;v=!1,Y(n)}else n!==U&&Y(n)}function Y(e){U=e,chrome.runtime.sendMessage({type:s.SUBMISSION_RESULT,status:e}).catch(()=>{})}function Se(){for(let e of me){let t=document.querySelector(e);if(t&&t.textContent&&t.textContent.trim())return t.textContent.trim()}return""}function K(){h&&(h.disconnect(),h=null),document.removeEventListener("click",Z,!0),b&&(clearTimeout(b),b=null),v=!1,U="",V=0}function Te(){u||(u=document.createElement("style"),u.id="mintcode-problem-blur",u.textContent=`
    [data-track-load="description_content"],
    .elfjS,
    div[data-key="description-content"],
    div[class*="question-content"] {
      filter: blur(12px) !important;
      user-select: none !important;
      pointer-events: none !important;
      transition: filter 0.4s ease;
    }
  `,document.head.appendChild(u))}function Q(){u&&(u.remove(),u=null)}function ve(e){if(M)return;M=!0,we(),Te(),be();let t=he();chrome.runtime.sendMessage({type:s.PROBLEM_LOADED,language:J,problemDetail:{title:t.title||e.problem?.title,content:t.content||e.problemDetail?.content||"",difficulty:t.difficulty||e.problem?.difficulty||e.problemDetail?.difficulty,titleSlug:e.problem?.titleSlug||e.problemDetail?.titleSlug}}).catch(()=>{}),ee().then(()=>{w(),chrome.runtime.sendMessage({type:s.MIC_STATUS,listening:!0}).catch(()=>{})}).catch(n=>{console.warn("Early mic permission request failed:",n)}),P(e.problem,async()=>{await Ie()}),chrome.runtime.sendMessage({type:s.OVERLAY_READY}).catch(()=>{})}function we(){f=document.createElement("style"),f.id="mintcode-styles",f.textContent=j,document.head.appendChild(f)}async function ee(){if(!navigator.mediaDevices?.getUserMedia)throw new Error("Microphone API not available");return y=await navigator.mediaDevices.getUserMedia({audio:!0}),y}async function Ie(){if(!p){p=!0,Q(),Ee(),ye();try{chrome.runtime.sendMessage({type:s.MIC_STATUS,listening:!0}).catch(()=>{}),await ee(),w(),H({onResult:(e,t)=>{N=e,chrome.runtime.sendMessage({type:s.TRANSCRIPT_UPDATE,final:e,interim:t}).catch(()=>{})},onError:e=>{console.error("STT error:",e),chrome.runtime.sendMessage({type:s.MIC_STATUS,listening:!1}).catch(()=>{})}})}catch(e){console.error("Microphone permission failed:",e),chrome.runtime.sendMessage({type:s.MIC_STATUS,listening:!1}).catch(()=>{}),chrome.runtime.sendMessage({type:s.ERROR,error:"Microphone permission denied. Allow access and try again."}).catch(()=>{}),p=!1;return}chrome.runtime.sendMessage({type:s.INTERVIEW_STARTED}).catch(()=>{})}}function G(){if(!p)return;p=!1,A(),w(),te(),K();let e=O();e&&e!==x&&(x=e,X(e)),chrome.runtime.sendMessage({type:s.INTERVIEW_FINISHED,transcript:N}).catch(()=>{})}function w(){y&&(y.getTracks().forEach(e=>e.stop()),y=null)}function te(){T&&(clearInterval(T),T=null)}function Re(){A(),w(),te(),K(),R(),_(),Q(),ke(),M=!1,p=!1,N="",x=""}function ke(){f&&(f.remove(),f=null)}})();
